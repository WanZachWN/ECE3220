#include <cmath> //cmath used on line 43 to absolute double value of imaginary if '-ve'
#include <iostream>
using namespace std;
//========================================================================================
/*
 - Complex class that has two private members type double which are real and imaginary.
 - Constructors for Cmplx class that initialize 0.0 to both real and imaginary.
 - Using member initializer list for Cmplx constructors.
 - Cmplx destructor
 - friend function for output and input stream when extracting and inserting streams for Cmplx
   class
 - friend function and operator overloading the + and - sign to add or subtract two complex class.
*/
class Cmplx {
	private:
    	double real, imag; // real and imaginary part of cmplx number
    	
	public:
    	Cmplx() : real(0.0), imag(0.0) //Default Constructor
    	{}
    	Cmplx(const double r, const double i) : real(r), imag(i)
    	{}
    	~Cmplx() // Destructor
    	{}
    	/*
    	* NB: additional function declarations go in here!
    	*/

    	friend ostream & operator << (ostream&, const Cmplx& c);
    	friend istream & operator >> (istream&, Cmplx& c);
    	friend Cmplx operator + (const Cmplx &lhs, const Cmplx &rhs);
    	friend Cmplx operator - (const Cmplx &lhs, const Cmplx &rhs);
};
//========================================================================================
/*- operator overloading << to output class Cmplx real and imaginary.
  - if imaginary is negative number, output '-' if positive output '+'
*/
ostream & operator << (ostream &os, const Cmplx& c)
{
    os << c.real;
    if(c.imag < 0)
    {
    	os << " - " << fabs(c.imag) << "i" << endl;
    }
    else
    {
    	os << " + " << c.imag << "i" << endl;
    }

    return os;
}
//========================================================================================
/*
  - operator overloading >> that ask user input for real and imaginary numbers for a Cmplx class
*/
istream & operator >> (istream &is, Cmplx &c)
{
    cout << "Enter Real: ";
    is >> c.real;
    cout << "Enter Imaginary: ";
    is >> c.imag;

    return is;
}
//========================================================================================
/*
  - operator overloading '+' where it returns a Cmplx object that adds the lhs and rhs
    of the real and imaginary values and returns the result of the Cmplx addition.
*/
Cmplx operator + (const Cmplx &lhs, const Cmplx &rhs)
{
    Cmplx result;
    result.real = lhs.real + rhs.real;
    result.imag = lhs.imag + rhs.imag;
    
    return result;
}
//========================================================================================
/*
  - operator overloading '-' where it returns a Cmplx object that subtracts the lhs and rhs
    of the real and imaginary values and returns the result of the Cmplx subtraction.
*/
Cmplx operator - (const Cmplx &lhs, const Cmplx &rhs)
{
    Cmplx result;
    result.real = lhs.real - rhs.real;
    result.imag = lhs.imag - rhs.imag;
    
    return result;
}
//========================================================================================
//main function
int main()
{
    //declare a type of Cmplx called a and initialize using member initializer
    Cmplx a(5.0, 5.0);
    //declare a type of Cmplx called b using default class initializer
    Cmplx b;
    //declare a type of Cmplx called b using default class initializer
    //this is to store the results
    Cmplx c;
    
    //ask user input for real and imaginary values of b
    cin >> b;
    //add a and b complex numbers and store into c
    c = a + b;
    //output the addition results that is stored in c
    cout << c;
    //subtract a and b complex numbers and store into c
    c = a - b;
    //output the subtraction results that is stored in c
    cout << c;
    
    return 0;
    
}
