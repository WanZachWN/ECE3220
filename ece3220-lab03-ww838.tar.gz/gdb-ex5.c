#include<stdio.h>
#include<malloc.h>
#include<stdlib.h>
void main()
{
    char *a;
    a = (char *)malloc(sizeof(char)*6);  
    a[0] = 'h';
    a[1] = 'e';
    a[2] = 'y';
    a[3] = '\0';
    free( a );
    a[0] = 'h';
    a[1] = 'e';
    a[2] = 'l';
    a[3] = 'l';
    a[4] = 'o';
    a[5] = '\0';
    printf("%s",a);
}
