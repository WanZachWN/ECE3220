#include <stdio.h>

void main()
{
	char p[] = "Mizzou";
	p[3] = 'P';
	printf("%s", p);
}
