#include <iostream>
#include <vector>
#include <map>
#include <sstream>
#include <cctype>
#include <string>
using namespace std;
//========================================================================================
/*Class Message
private:
- string variable called message
public
- Empty constructor that will ask for a user input
- Parametric constructor that will take a message and store into string message
	example: Message message("some message");
- class message destructor
- virtual get message function
- virtual print message function
*/
class Message
{
	private:
	string message;
	public:
	Message()
	{
		getline(cin, message);
	}
	Message(const string m) : message(m) {}
	~Message()
	{}
	virtual string GetMessage();
	virtual void PrintMessage();
};
//========================================================================================
/*Class MorseCodeMessage
private:
- string variable called morse_code
public
- void function translate that accepts a type string
- print message function that will overload the parent class similar function
- get message function that will overload the parent class similar function
*/
class MorseCodeMessage : public Message
{
	private:
	string morse_code;
	public:
	void Translate(string);
	void PrintMessage();
	string GetMessage();
};
//========================================================================================
/*Class MessageStack
private:
- string variable called message_s
- vector of type string called messagestack
public
- Parametric constructor that will store into message_s
- Destructor for MessageStack Class
- Push function type void
- Pop function type void
- print message function that will overload other print function
- set message function that accepts a type string
*/
class MessageStack
{
	private:
	string message_s;
	vector <string> messagestack;
	public:
	MessageStack(const string ms) : message_s(ms)
	{}
	~MessageStack()
	{}
	void Push();
	void Pop();
	void PrintMessage();
	void SetMessage(string);
};
//========================================================================================
//return a type string which is message because it is private
string Message::GetMessage()
{
	return this->message;
}
//========================================================================================
//prints the message stored in string message
void Message::PrintMessage()
{
	cout << message << endl;
}
//========================================================================================
/*Translate function
- accepts messages using pass by value(a copy) therefore not changing
  the original message
- using map class to map each characters in the alphabet onto the morse code
  this is to prevent from using two string arrays and iterate through one of
  the arrays
- ostringstream to store our translated letters to morsecode
- a for loop to iterate through the whole message string
   - copies the letters of msg at each location of the iteration
   - if the letter is an uppercase change it to lowercase
     to match with the mapping as it is set to lowercase
   - if the letter is a space, insert a space into our ostringstream
   - else it is a character and search for a similar alphabet in the mapping using
     the function find() for the map class
- set the translated message onto string morse_code and return.
*/
void MorseCodeMessage::Translate(string msg)
{
	map<string, string> morse{
	  {"a",".-"}, {"b","-..."}, {"c","-.-."}, {"d","-.."}, {"e","."},
	  {"f","..-."}, {"g","--."}, {"h","...."}, {"i",".."}, {"j",".---"},
	  {"k","-.-"}, {"l",".-.."}, {"m","--"}, {"n","-."}, {"o","---"},
	  {"p",".--."}, {"q","--.-"}, {"r",".-."}, {"s","..."}, {"t","-"},
	  {"u","..-"}, {"v","...-"}, {"w",".--"}, {"x","-..-"}, {"y","-.--"},
	  {"z","--.."}, {"1",".----"}, {"2","..---"}, {"3","...--"}, {"4","....-"},
	  {"5","....."}, {"6","-...."}, {"7","--..."}, {"8","---.."}, {"9","----."},
	  {"0","-----"}, {".",".-.-.-"}, {",","--..--"}
	};
	ostringstream morsecode;
	string change;
	for(int i = 0; i < msg.size(); i++)
	{
		change = msg[i];//copy a character
		if(isupper(change[0]))//accepts a character
		{
			change[0] = tolower(change[0]);//accepts a character
		}
		if(isspace(change[0]))//accepts a character
		{
			morsecode << " ";
		}
		else
		{
			auto search = morse.find(change);//accepts a string
			morsecode << search->second;
		}
	}
	this->morse_code = morsecode.str();
	return;
}
//========================================================================================
//prints the message stored in string morse_code
void MorseCodeMessage::PrintMessage()
{
	cout << morse_code << endl;
}
//========================================================================================
//return a type string which is morse_code because it is private
string MorseCodeMessage::GetMessage()
{
	return this->morse_code;
}
//========================================================================================
//uses the vector push_back function to push any messages onto the stack
void MessageStack::Push()
{
	messagestack.push_back(message_s);
	
	return;
}
//========================================================================================
/*uses the vector pop_back function to pop any messages off the stack
- if the stack is empty, it will output telling the user that the stack is
  empty and return to main
- if the stack is not empty, it will pop the last element in the stack
  and return to main.
*/
void MessageStack::Pop()
{
	if(messagestack.empty())
	{
		cout << "Cannot pop! Stack is Empty." << endl;
		return;
	}
	messagestack.pop_back();
	
	return;
}
//========================================================================================
/*prints the message stored in vector <string> messagestack
- if the stack is empty it will give the output telling the user
  that the stack is empty and return to main
- if stack is not empty it will iterate through the vector and output all of
  the currently stored messages and return to main once
  it reaches the end.
*/
void MessageStack::PrintMessage()
{
	if(messagestack.empty())
	{
		cout << "Stack is empty" << endl;
		return;
	}
	for(vector<string>::iterator it = messagestack.begin(); it != messagestack.end(); it++)
	{
		cout << *it << endl;
	}
	cout << endl;
	return;
}
//========================================================================================
//pass by value to set the message passed to string message_s
void MessageStack::SetMessage(string message)
{
	this->message_s = message;
	return;
}
