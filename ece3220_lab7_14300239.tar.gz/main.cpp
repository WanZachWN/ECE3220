#include "morse_code_gen.h" //include header file
//main function
int main()
{
	//initialization of stack class but is not pushed onto the stack
	MessageStack msg_stack("Hellow World!");
	
	//entry is for user input type int when choosing an option given
	int entry = 0;
	//while loop to keep the program running until user ask to stop
	while(entry != 4)
	{
		//user is asked to choose one of the following
		cout << "Please Choose One of the following:" << endl <<
			"1 - Enter Message Text" << endl <<
			"2 - Print Stored Messages" << endl <<
			"3 - Remove Last Message from Stored Messages" << endl <<
			"4 - Exit the Program" << endl <<
			"Choice: ";
			cin >> entry;
			cin.ignore();
			cout << endl;
		switch(entry)
		{
			case 1:/* enter text and ask if it requires a translation or not
				- if user chooses yes, the message will be translate and pushed onto the stack.
				- if user chooses no, the original message is kept and pushed onto the stack.
				- if user chooses other than yes or no(different number) then it will ask the user again
				  for a proper input*/
				{
					entry = 0;
					cout << "Enter text: ";
					Message message;
										
					while(entry < 1 || entry > 2)
					{
						cout << "Would you like to translate?" << endl <<
						"1 - Yes" << endl <<
						"2 - No" << endl <<
						"Choice: ";
						cin >> entry;
						cout << endl;
						
						if(entry == 1)
						{
							MorseCodeMessage morse_code;
							morse_code.Translate(message.GetMessage());
							msg_stack.SetMessage(morse_code.GetMessage());
							msg_stack.Push();
						}
						else if(entry == 2)
						{
							msg_stack.SetMessage(message.GetMessage());
							msg_stack.Push();
						}
						else
						{
							cout << "Wrong input, please try again." << endl;
						}
					}
				}
				break;
				
			case 2://printing all messages stored in the stack.
				cout << "Printing Stored Messages" << endl;
				msg_stack.PrintMessage();
				break;
				
			case 3://pop last element on the stack
				msg_stack.Pop();
				break;
				
			case 4://if user chooses to exit
				break;
				
			default://if user enter other than given options(1-4)
				cout << "Wrong input, please try again." << endl;
				break;
		}
	}
	//end of program
	return 0;
}
