#include "substring.h"

int main(int argc, char* argv[])
{
	int i = 0; //indicator for threads
	int exitcode = 0;//exit code
	int num_other_thread, num_first_thread, min_first_search;
	srand(time(NULL));
	
	//initialize our word desired word search
	Count c_x("x");
	Count c_os("os");
	Count c_cpu("cpu");
	Count c_disk("disk");
	Count c_cache("cache");
	
	try	
	{		
		NUMBER_OF_THREADS = check(argc, argv);//checking
		
		//initialize threads
		pthread_t thread[NUMBER_OF_THREADS];
		
		/*num_other_thread - this is for other threads os, cpu, disk, and cache
					due to lower probability of finding it
		  num_first_thread - this is for x due to higher chance of finding therefore allocate
		  			more threads
		  min_first_search - starting thread for x
		*/
		num_other_thread = NUMBER_OF_THREADS/5;
		num_first_thread = NUMBER_OF_THREADS - num_other_thread*4;
		min_first_search = NUMBER_OF_THREADS - num_first_thread;
		
		//number of char to reach for each thread
		int thread_reach = MAX_CHAR/num_other_thread;
		int fthread_reach = MAX_CHAR/num_first_thread;
		
		//how many times to read a character by a thread for each word
		c_x.max_reach = fthread_reach;
		c_os.max_reach = thread_reach;
		c_cpu.max_reach = thread_reach;
		c_disk.max_reach = thread_reach;
		c_cache.max_reach = thread_reach;
		
		for(i = 0; i < NUMBER_OF_THREADS-1; i++)
		{
			if(i < min_first_search)
			{
				locate.push_back(thread_reach);
			}
			else
			{
				locate.push_back(fthread_reach);
			}
		}

		//write to a file thread
		pthread_create(&thread[0], NULL, WriteFile, NULL);
		pthread_join(thread[0], NULL);
		
		//for loop to initialize thread
		for(i = 1; i <= num_other_thread; i++)
		{
			
			c_os.thread_id = i-1;
			c_cpu.thread_id = num_other_thread+i-1;
			c_disk.thread_id = 2*num_other_thread+i-1;
			c_cache.thread_id = 3*num_other_thread+i-1;
			
			locate[i] = locate[i]*(i-1);
			locate[num_other_thread+i] = locate[num_other_thread+i]*(i-1);
			locate[2*num_other_thread+i] = locate[2*num_other_thread+i]*(i-1);
			locate[3*num_other_thread+i] = locate[3*num_other_thread+i]*(i-1);
			
			pthread_create(&thread[i], NULL, Find, &c_os);
			pthread_create(&thread[num_other_thread+i], NULL, Find, &c_cpu);
			pthread_create(&thread[2*num_other_thread+i], NULL, Find, &c_disk);
			pthread_create(&thread[3*num_other_thread+i], NULL, Find, &c_cache);
			
		}
		for(i = NUMBER_OF_THREADS-1; i > min_first_search; i--)
		{
			c_x.thread_id = i;
			locate[i] = locate[i]*i;
			pthread_create(&thread[i], NULL, Find, &c_x);
		}
		
		//join threads
		for(i = 1; i < NUMBER_OF_THREADS; i++)
		{
			pthread_join(thread[i], NULL);
		}
		
		sleep(60);
		c_x.Print();
		c_os.Print();
		c_cpu.Print();
		c_disk.Print();
		c_cache.Print();
	}
	//exception thrown for help on how to use the program
	catch(bool)
	{	
		Help();
		exitcode = 0;
	}
	//throw an exception if passing a runtime error
	catch(const runtime_error &err)
	{
		cerr << "ERROR: " << err.what() << endl;
		Help();
		exitcode = 1;
	}
	//any unexpected exception thrown
	catch(...)
	{
		cerr << "ERROR: Unexpected exception thrown" << endl;
		Help();
		exitcode = 2;
	}
	return exitcode;// exit
}
