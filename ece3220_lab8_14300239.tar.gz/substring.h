#include <iostream>
#include <string>
#include <pthread.h>
#include <fstream>
#include <stdexcept>
#include <cstring> //c string manipulator
#include <sstream>
#include <vector>
#include <unistd.h>
using namespace std;

#define MAX_CHAR 250000000
int NUMBER_OF_THREADS = 0;
vector<int> locate;
//initialize mutex
pthread_mutex_t writer_mutex;
//====================================================================================================
//class for counting the critical section of each word
class Count{
	public:
	Count(const string a) : str(a)
	{}
	string str;
	int max_reach;
	int i;
	int thread_id;
	void Increment();
	void Print();
};
//====================================================================================================
//increment the counter
void Count::Increment()
{
	this->i++;
}
//====================================================================================================
//print the counter of how many words were found
void Count::Print()
{
	cout << this->str << " has " << i << " in big.txt" << endl;
}
//====================================================================================================
/*Void type function to write onto a file
  - initialize character, iterator and max iteration
  - lock mutex to only allow the writer thread to run
  - open file
  	- if fail throw exception
  - loop to randomize between inserting uppercase and lower case letters
  - increment iterator
  - once it reaches the max characters we want to store it will close the file
  - unlock mutex to allow other threads
*/
void* WriteFile(void* arg)
{
	char a;
	int i = 0;
	
	
	ofstream save("big.txt");
	
	if(!save)
	{
		ostringstream error_msg;
		error_msg << "Error opening big.txt" << ends;
		throw runtime_error(error_msg.str());	
	}
	pthread_mutex_lock(&writer_mutex);
	while(i != MAX_CHAR-1)
	{
		if(rand()%2 == 1)
		{
			a = 'a' + rand() % 26;
			save << a;
		}
		else
		{
			a = 'A' + rand() % 26;
			save << a;
		}
		i++;
	}
	pthread_mutex_unlock(&writer_mutex);
	save.close();
	pthread_exit(NULL);
}
//====================================================================================================
/*Void type function to write onto a file
  - initialize 
  	- count a counter for each word we find
  	- i  for iterating string to compare with letter and pos of the word
  	  we want to find
  	- content to store our word if we find a complete match
  	- char_file to store each character when we read file
  - lock mutex to only allow the reader thread to run
  - open file
  	- if fail throw exception
  - loop to read file
  - get character by character in the file
  - store into string
  - if last element exit
  - if capital then change to lower
  - if character stored is the same with character in the word and same location
    increment to next character in the word we want to check
  - if it is the last character in the string
  	- set our i to 0 to restart checking
   	- increase count as we have found a matching word
   	- clear what is stored in string and restart
  - if the character does not match then clear what is stored in string
  - close file
  - unlock mutex
  - print the number of words we found in the file
*/
void* Find(void* count_v)
{
	ifstream read;
	Count* inc = static_cast<Count*>(count_v);
	int count = 0;
	int i = 0;
	int j = 0;
	string content;
	char char_file;
	int end = locate[inc->thread_id] + inc->max_reach;
	
	read.open("big.txt");
	if(!read.is_open())
	{
		ostringstream error_msg;
		error_msg << "Error opening big.txt" << ends;
		throw runtime_error(error_msg.str());	
	}
	
	while(1)
	{
		read.get(char_file);
		if(j >= locate[inc->thread_id])
		{
			content.push_back(char_file);
			
			if(j == end)
			{
				break;
			}
			if(isupper(content[i]))
			{
				content[i] = tolower(content[i]);
			}
			if(content[i] == inc->str[i])
			{
				i++;
				if(content.size() == inc->str.size())
				{
					i = 0;
					pthread_mutex_lock(&writer_mutex);
					inc->Increment();
					pthread_mutex_unlock(&writer_mutex);
					content.clear();
				}
			}
			else
			{
				content.clear();
				i = 0;
			}
		}
		j++;
	}
	read.close();
	pthread_exit(NULL);
	
}
//====================================================================================================
/*check if calling program is done properly.
  - Initialize
  	- n is iterator
  	- endptr is a pointer type character that returns null when convert char* to int
  - if does not satisfy the minimum amount of arguments needed throw exception
  	- if argc is only 1 and it is not calling for help
  	 throw exception not enough arguments 
  - loop to check argv[]
  	 - if n is more than argc-1 means reach end of calling program arguments
  	 	- if number of threads is not specified then throw exception
  	 - if any part in the program is called -h for help then print help
  	 - -n is to insert number of threads
  	 	- convert next element to int if fail to conver throw exception
  	 	- if number of threads does not satisfy requirements then throw
  	 	  exception
  - increment n by 2
  - return number of threads
*/
int check(int argc, char *argv[])
{
	int n = 1;
	char* endptr = NULL;
	int num_threads = -1;
	
	if(argc < 3)
	{
		if(argc == 1 || strcmp(argv[n], "-h") != 0)
		{
			ostringstream err;
			err << "Invalid calling program" << ends; 
			throw runtime_error(err.str());
		}
		throw (true);
	}
	
	while(n < argc)
	{
		if(n >= argc-1)
		{
			if(num_threads == -1)
			{
				ostringstream error_msg;
				error_msg << "Number of threads is not stated" << ends;
				throw runtime_error(error_msg.str());
			}
		}
		//if any of the elements ask for help
		if(strcmp(argv[n], "-h") == 0 || strcmp(argv[n+1], "-h") == 0)
		{
			throw (true);
		}
		
		//compare string if "-n" user is giving data file number. Convert next element
		//to integer
		if(strcmp(argv[n], "-n") == 0)
		{
			num_threads = strtod(argv[n+1], &endptr);
			if(*endptr != '\0')
			{
				ostringstream error_msg;
				error_msg << "In valid conversion of non-numeric type '"
					  << argv[n+1] << "' to a numeric type" << ends;
				throw runtime_error(error_msg.str());
			}
			if(num_threads < 6)
			{
				ostringstream error_msg;
				error_msg << "Invalid number of threads. Atleast 6 threads needed." << ends;
				throw runtime_error(error_msg.str());
			}
		}
		n += 2;
	}
	return num_threads;
}
//====================================================================================================
//display help to user on how to use the program.
void Help()
{
	cout << "WW838's Lab 8\n" << 
		"-n num_threads	>> To call and run with specific number of threads\n" <<
		"-h		>> Help\n" <<
		"Examples:\n" <<
		"./main -n 20\n";
}
