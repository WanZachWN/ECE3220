#include <iostream>
#include <cstdlib>
#include <unistd.h>
#include <pthread.h>
using namespace std;

#define NUM_OF_THREADS 40


//mutex between writer and reader
pthread_mutex_t writelock;


// Define thread tasks
void* reader(void* param);
void* writer(void* param);



int main(int argc, char* argv[]) 
{
	pthread_t tid[NUM_OF_THREADS];
	int thread_no[NUM_OF_THREADS];
	int thread_counter = 0;
	int i = 0;
	srand(time(NULL));

	//init mutex
	if(pthread_mutex_init(&writelock, NULL) != 0)
	{
		printf("ERROR: Cannot initiate mutex\n");
		return -1;
	}
	
	//create NUM_OF_WRITER amount of writer threads
	for(i=0; i<NUM_OF_THREADS; i++)
	{
		thread_no[i] = i;
		if( (rand()%3) > 1 )
		{
			thread_counter = 0;//set to 0 as we have write
			pthread_create(&tid[i], NULL, writer, &thread_no[i]);
		}
		else
		{
			if(thread_counter == 3)
			{
				i--;//redo the thread
			}
			else
			{
				pthread_create(&tid[i], NULL, reader, &thread_no[i]);
				thread_counter++;
			}
		}
	}
	
	for(i = 0; i < NUM_OF_THREADS; i++)
	{
		pthread_join(tid[i], NULL);
	}
	
	pthread_mutex_destroy(&writelock);
	return 0;
}

//WRITER
void* writer(void* param)
{
	int i = 0;
	int* thread_no = (int*)param;
	
	//obtain the lock
	pthread_mutex_lock(&writelock);

		// Critical Section BEGIN
		cout << "writer " << *thread_no << " began writing\n";
		sleep(2);
		cout << "writer " <<  *thread_no <<" finished writing\n";
		// Critical Section END

	//release the lock
	pthread_mutex_unlock(&writelock);
	
	pthread_exit(NULL);
}



//READER
void* reader(void* param)
{
	int i = 0;
	int* thread_no = (int*)param;
	
	//obtain the lock
	pthread_mutex_lock(&writelock);

		// Critical Section BEGIN
		cout << "reader " << *thread_no << " began reading\n";
		sleep(1);
		cout << "reader " << *thread_no << " finished reading\n";
		// Critical Section END

	//release the lock
	pthread_mutex_unlock(&writelock);
	
	pthread_exit(NULL);
}



