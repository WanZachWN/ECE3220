#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#define MAX 50
//============================================================================================
//struct of type Student
typedef struct Student{
	char name[MAX];
	struct Student *next, *prev;
}Student;
//============================================================================================
//insert new student in list
Student *insert_student(Student *node, char *name, char *prev_name);
//============================================================================================
//delete a student from the lsit
int delete_student(Student *node, char *name);
//============================================================================================
//search the student
Student *search_list(Student *node, char *name);
//============================================================================================
//swap two students in list
//swap was changed to type student for returning the updated list to the head
Student *swap(Student *node1, Student *node2);
//============================================================================================
//empty doubly linked-list
void free_list(Student *node);

//============================================================================================
//enumeration of bool
typedef enum {true , false} bool;
//============================================================================================
